<?php

/* artist_form_page.html.twig */
class __TwigTemplate_bc61ae023acd8a92e7d6a2721bd9edaa5fd7a2c2ea9f0885a62172536f8c1de0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("command.html.twig", "artist_form_page.html.twig", 1);
        $this->blocks = array(
            'form' => array($this, 'block_form'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "command.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40ba40632d442faec5710393d3a5a121f602fcb0b2e154b08c2ff1bae722b976 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40ba40632d442faec5710393d3a5a121f602fcb0b2e154b08c2ff1bae722b976->enter($__internal_40ba40632d442faec5710393d3a5a121f602fcb0b2e154b08c2ff1bae722b976_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "artist_form_page.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_40ba40632d442faec5710393d3a5a121f602fcb0b2e154b08c2ff1bae722b976->leave($__internal_40ba40632d442faec5710393d3a5a121f602fcb0b2e154b08c2ff1bae722b976_prof);

    }

    // line 2
    public function block_form($context, array $blocks = array())
    {
        $__internal_dadd29d2441ddab97b84f58e594633edca988bfacdc9767026068116708d65e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dadd29d2441ddab97b84f58e594633edca988bfacdc9767026068116708d65e4->enter($__internal_dadd29d2441ddab97b84f58e594633edca988bfacdc9767026068116708d65e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form"));

        // line 3
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 5
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_dadd29d2441ddab97b84f58e594633edca988bfacdc9767026068116708d65e4->leave($__internal_dadd29d2441ddab97b84f58e594633edca988bfacdc9767026068116708d65e4_prof);

    }

    public function getTemplateName()
    {
        return "artist_form_page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 5,  44 => 4,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{%extends \"command.html.twig\"%}
{%block form%}
{{form_start(form)}}
{{form_widget(form)}}
{{form_end(form)}}
{%endblock%}", "artist_form_page.html.twig", "C:\\xampp\\htdocs\\scb\\app\\Resources\\views\\artist_form_page.html.twig");
    }
}
