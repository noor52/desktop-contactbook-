<?php

/* command.html.twig */
class __TwigTemplate_66bc6fa0fc7296829da3a9604d60bc4d46e66261120398cdfc340bdb430828cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'table' => array($this, 'block_table'),
            'form' => array($this, 'block_form'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a97bad1db8ec8f6df798c8ed50a0f0816ba48a177ca2291dbe0ddfd4b18c3cf2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a97bad1db8ec8f6df798c8ed50a0f0816ba48a177ca2291dbe0ddfd4b18c3cf2->enter($__internal_a97bad1db8ec8f6df798c8ed50a0f0816ba48a177ca2291dbe0ddfd4b18c3cf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "command.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
      ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('body', $context, $blocks);
        // line 35
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 36
        echo "    </body>
</html>
";
        
        $__internal_a97bad1db8ec8f6df798c8ed50a0f0816ba48a177ca2291dbe0ddfd4b18c3cf2->leave($__internal_a97bad1db8ec8f6df798c8ed50a0f0816ba48a177ca2291dbe0ddfd4b18c3cf2_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7a14952923a7e68d4eee3e7152cff7844f1ae7f534a8632ac6954f1d57d072c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a14952923a7e68d4eee3e7152cff7844f1ae7f534a8632ac6954f1d57d072c0->enter($__internal_7a14952923a7e68d4eee3e7152cff7844f1ae7f534a8632ac6954f1d57d072c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_7a14952923a7e68d4eee3e7152cff7844f1ae7f534a8632ac6954f1d57d072c0->leave($__internal_7a14952923a7e68d4eee3e7152cff7844f1ae7f534a8632ac6954f1d57d072c0_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c434d6a147eb4ca587ab8f0418ac421e559059a1581b7f991ea96086039984d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c434d6a147eb4ca587ab8f0418ac421e559059a1581b7f991ea96086039984d1->enter($__internal_c434d6a147eb4ca587ab8f0418ac421e559059a1581b7f991ea96086039984d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bootstrap/css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">
        <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("custom/css/custom.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">
       ";
        
        $__internal_c434d6a147eb4ca587ab8f0418ac421e559059a1581b7f991ea96086039984d1->leave($__internal_c434d6a147eb4ca587ab8f0418ac421e559059a1581b7f991ea96086039984d1_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_63e85402f1ee997d701932d0f3424136df125d0a3a8091995cc395127202d7e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63e85402f1ee997d701932d0f3424136df125d0a3a8091995cc395127202d7e4->enter($__internal_63e85402f1ee997d701932d0f3424136df125d0a3a8091995cc395127202d7e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "            <div class=\"row\"style=\"\">
                <div class=\"col-md-2\"style=\"background:oldlace;height: 500px\">
                </div>
                  <div class=\"col-md-8 bg1\"style=\"height:300px\">
                     
                          <div class=\"row\"style=\"background: #777;opacity: .6\">
                              <div class=\"col-md-4\"style=\"background:graytext;height: 200px;\">
                                   ";
        // line 21
        $this->displayBlock('table', $context, $blocks);
        // line 22
        echo "                              </div>
                              <div class=\"col-md-4\"style=\"background:oldlace;height: 200px\">
                                  ";
        // line 24
        $this->displayBlock('form', $context, $blocks);
        // line 25
        echo "                              </div>
                              <div class=\"col-md-4\"style=\"background:olive;height: 200px\">
                              </div>
                          </div>
                          
                </div>
                 <div class=\"col-md-2\"style=\"background:oldlace;height: 500px\">
                </div>    
            </div>
        ";
        
        $__internal_63e85402f1ee997d701932d0f3424136df125d0a3a8091995cc395127202d7e4->leave($__internal_63e85402f1ee997d701932d0f3424136df125d0a3a8091995cc395127202d7e4_prof);

    }

    // line 21
    public function block_table($context, array $blocks = array())
    {
        $__internal_94d2bc2f8066060be4b47677364aa18e29716078b8d882c28645578bba682af1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94d2bc2f8066060be4b47677364aa18e29716078b8d882c28645578bba682af1->enter($__internal_94d2bc2f8066060be4b47677364aa18e29716078b8d882c28645578bba682af1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "table"));

        
        $__internal_94d2bc2f8066060be4b47677364aa18e29716078b8d882c28645578bba682af1->leave($__internal_94d2bc2f8066060be4b47677364aa18e29716078b8d882c28645578bba682af1_prof);

    }

    // line 24
    public function block_form($context, array $blocks = array())
    {
        $__internal_8507beef66f9a6f6f08e3e9ba890ac2e26f7e3ae9bb37b9f08e5a3dee217f4b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8507beef66f9a6f6f08e3e9ba890ac2e26f7e3ae9bb37b9f08e5a3dee217f4b3->enter($__internal_8507beef66f9a6f6f08e3e9ba890ac2e26f7e3ae9bb37b9f08e5a3dee217f4b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form"));

        
        $__internal_8507beef66f9a6f6f08e3e9ba890ac2e26f7e3ae9bb37b9f08e5a3dee217f4b3->leave($__internal_8507beef66f9a6f6f08e3e9ba890ac2e26f7e3ae9bb37b9f08e5a3dee217f4b3_prof);

    }

    // line 35
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1bdfcd5d93489507e54e8497bd8a515d76742b8a7e61437de215f584179ff894 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bdfcd5d93489507e54e8497bd8a515d76742b8a7e61437de215f584179ff894->enter($__internal_1bdfcd5d93489507e54e8497bd8a515d76742b8a7e61437de215f584179ff894_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_1bdfcd5d93489507e54e8497bd8a515d76742b8a7e61437de215f584179ff894->leave($__internal_1bdfcd5d93489507e54e8497bd8a515d76742b8a7e61437de215f584179ff894_prof);

    }

    public function getTemplateName()
    {
        return "command.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 35,  143 => 24,  132 => 21,  116 => 25,  114 => 24,  110 => 22,  108 => 21,  99 => 14,  93 => 13,  84 => 8,  79 => 7,  73 => 6,  61 => 5,  52 => 36,  49 => 35,  47 => 13,  40 => 10,  38 => 6,  34 => 5,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
      {% block stylesheets %}
        <link href=\"{{asset('bootstrap/css/bootstrap.css')}}\" rel=\"stylesheet\" type=\"text/css\">
        <link href=\"{{asset('custom/css/custom.css')}}\" rel=\"stylesheet\" type=\"text/css\">
       {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}
            <div class=\"row\"style=\"\">
                <div class=\"col-md-2\"style=\"background:oldlace;height: 500px\">
                </div>
                  <div class=\"col-md-8 bg1\"style=\"height:300px\">
                     
                          <div class=\"row\"style=\"background: #777;opacity: .6\">
                              <div class=\"col-md-4\"style=\"background:graytext;height: 200px;\">
                                   {% block table %}{%endblock%}
                              </div>
                              <div class=\"col-md-4\"style=\"background:oldlace;height: 200px\">
                                  {% block form %}{%endblock%}
                              </div>
                              <div class=\"col-md-4\"style=\"background:olive;height: 200px\">
                              </div>
                          </div>
                          
                </div>
                 <div class=\"col-md-2\"style=\"background:oldlace;height: 500px\">
                </div>    
            </div>
        {% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "command.html.twig", "C:\\xampp\\htdocs\\scb\\app\\Resources\\views\\command.html.twig");
    }
}
