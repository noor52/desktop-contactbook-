<?php

/* artist_info_page.html.twig */
class __TwigTemplate_c3e52fd5f9bdde8fbe7c64d8aaa15da18aea27bcb86cb41b85e2f6c0336911f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("command.html.twig", "artist_info_page.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "command.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c57ee941f96315274256cf267c149c11fbd196434cae5e9a0745c4bc5a9c3e95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c57ee941f96315274256cf267c149c11fbd196434cae5e9a0745c4bc5a9c3e95->enter($__internal_c57ee941f96315274256cf267c149c11fbd196434cae5e9a0745c4bc5a9c3e95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "artist_info_page.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c57ee941f96315274256cf267c149c11fbd196434cae5e9a0745c4bc5a9c3e95->leave($__internal_c57ee941f96315274256cf267c149c11fbd196434cae5e9a0745c4bc5a9c3e95_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_140c7db19a3e3d5ddae4e6976cce4aee01ef05e40025c1cac42bb014a9c471e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_140c7db19a3e3d5ddae4e6976cce4aee01ef05e40025c1cac42bb014a9c471e0->enter($__internal_140c7db19a3e3d5ddae4e6976cce4aee01ef05e40025c1cac42bb014a9c471e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<h2 class=\"text-center\">Mini Contact  Book</h2>
<td><a class=\"btn btn-primary\" href=\"";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("infoform");
        echo "\">INSERT</a></td>

<table class=\"table table-striped table-bordered\">
    <tr> 
         <th>ID </th>
        <th> Name </th>
        <th>Contact NO </th>
        <th>DOB</th>
        <th>Address</th>
        <th>Next Meet At</th>
    </tr>
    ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) ? $context["results"] : $this->getContext($context, "results")));
        foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
            // line 16
            echo "        <tr>
            <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "id", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "contactno", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "dob", array()), "html", null, true);
            echo "</td>
             <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "address", array()), "html", null, true);
            echo "</td>
             <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], "nextmeetingat", array()), "html", null, true);
            echo "</td>
           <td><a class=\"btn btn-danger\" href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("deleteinfo", array("id" => $this->getAttribute($context["result"], "id", array()))), "html", null, true);
            echo "\">DELETE</a></td>
             <td><a class=\"btn btn-danger\" href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("infoform", array("id" => $this->getAttribute($context["result"], "id", array()))), "html", null, true);
            echo "\">UPDATE</a></td>
            
        </tr>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "
</table>

<button class=\"btn btn-success\" type=\"submit\">Button</button>


";
        
        $__internal_140c7db19a3e3d5ddae4e6976cce4aee01ef05e40025c1cac42bb014a9c471e0->leave($__internal_140c7db19a3e3d5ddae4e6976cce4aee01ef05e40025c1cac42bb014a9c471e0_prof);

    }

    public function getTemplateName()
    {
        return "artist_info_page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 28,  92 => 24,  88 => 23,  84 => 22,  80 => 21,  76 => 20,  72 => 19,  68 => 18,  64 => 17,  61 => 16,  57 => 15,  43 => 4,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{%extends \"command.html.twig\"%}
{%block body%}
<h2 class=\"text-center\">Mini Contact  Book</h2>
<td><a class=\"btn btn-primary\" href=\"{{path('infoform')}}\">INSERT</a></td>

<table class=\"table table-striped table-bordered\">
    <tr> 
         <th>ID </th>
        <th> Name </th>
        <th>Contact NO </th>
        <th>DOB</th>
        <th>Address</th>
        <th>Next Meet At</th>
    </tr>
    {%for result in results%}
        <tr>
            <td>{{result.id}}</td>
            <td>{{result.name}}</td>
            <td>{{result.contactno}}</td>
            <td>{{result.dob}}</td>
             <td>{{result.address}}</td>
             <td>{{result.nextmeetingat}}</td>
           <td><a class=\"btn btn-danger\" href=\"{{path('deleteinfo',{'id':result.id})}}\">DELETE</a></td>
             <td><a class=\"btn btn-danger\" href=\"{{path('infoform',{'id':result.id})}}\">UPDATE</a></td>
            
        </tr>
  {%endfor%}

</table>

<button class=\"btn btn-success\" type=\"submit\">Button</button>


{%endblock%}
{# empty Twig template #}
", "artist_info_page.html.twig", "C:\\xampp\\htdocs\\scb\\app\\Resources\\views\\artist_info_page.html.twig");
    }
}
