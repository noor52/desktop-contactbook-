<?php

namespace AppBundle\Controller;



use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;


use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use AppBundle\Entity\Info;



class  DefaultController extends controller {



    
    
    /**
     * @Route("/infoform",name="infoform")
     */
    public function studentAction(Request $request){
        
        $info = new Info();
 


    $emm = $this->getDoctrine()->getManager();
    if($request->query->get('id')!="")
    {
    $info=$emm->find('AppBundle\Entity\Info', $request->query->get('id'));
    $Info=$info;
    }
    
    
    $form = $this->createFormBuilder($info)
    
      
        -> add('name',TextType::class,array('label'=>'Name'))
        -> add('contactno',TextType::class,array('label'=>'Contact No'))
        -> add('dob',TextType::class,array('label'=>'Note'))
       -> add('address',TextType::class,array('label'=>'Address'))
      -> add('nextmeetingat',TextType::class,array('label'=>'Next Meet At'))       
        -> add('save',SubmitType::class,array('label'=>'SUBMIT'))        
        ->getForm();
       
    $form->handleRequest($request);
     
    if($form->isSubmitted() && $form->isValid()){
        $Info=$form->getData();
        $em = $this -> getDoctrine() -> getManager();
        $em -> persist($Info);
        $em -> flush();
        return $this->redirectToRoute('info');
    }
    return $this->render('artist_form_page.html.twig',array('form'=>$form->createView(),));
}

/**
 * @Route("/info",name="info")
 */

public function printAction(){
    
    $em = $this->getDoctrine()->getManager();
    $query = $em->createQuery('select u from AppBundle\Entity\Info u');
    $results=$query->getResult();
     return $this->render('artist_info_page.html.twig',array('results'=>$results));
}
   /**
 * @Route("/delete",name="deleteinfo")
 */
public function deleteAction(Request $request){
    $id=$request->query->get('id');
    $em = $this->getDoctrine()->getManager();
    //$query = $em->createQuery('delete from AppBundle\Entity\Artist u where u.artistId=:id');
    //$query->setParameter('id',$id);
    //$results=$query->getResult();
    $info=$em->find('AppBundle\Entity\Info', $request->query->get('id'));
    $em->remove($info);
    $em->flush();
    return $this->redirectToRoute('info');
}     
 
}