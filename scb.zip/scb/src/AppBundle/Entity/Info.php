<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Info
 *
 * @ORM\Table(name="info")
 * @ORM\Entity
 */
class Info
{
    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=50, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="contactno", type="string", length=50, nullable=false)
     */
    private $contactno;

    /**
     * @var string
     *
     * @ORM\Column(name="dob", type="string", length=20, nullable=true)
     */
    private $dob;

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=100, nullable=false)
     */
    private $address;

    /**
     * @var string
     *
     * @ORM\Column(name="nextmeetingat", type="string", length=30, nullable=true)
     */
    private $nextmeetingat;

    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;



    /**
     * Set name
     *
     * @param string $name
     * @return Info
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set contactno
     *
     * @param string $contactno
     * @return Info
     */
    public function setContactno($contactno)
    {
        $this->contactno = $contactno;

        return $this;
    }

    /**
     * Get contactno
     *
     * @return string 
     */
    public function getContactno()
    {
        return $this->contactno;
    }

    /**
     * Set dob
     *
     * @param string $dob
     * @return Info
     */
    public function setDob($dob)
    {
        $this->dob = $dob;

        return $this;
    }

    /**
     * Get dob
     *
     * @return string 
     */
    public function getDob()
    {
        return $this->dob;
    }

    /**
     * Set address
     *
     * @param string $address
     * @return Info
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set nextmeetingat
     *
     * @param string $nextmeetingat
     * @return Info
     */
    public function setNextmeetingat($nextmeetingat)
    {
        $this->nextmeetingat = $nextmeetingat;

        return $this;
    }

    /**
     * Get nextmeetingat
     *
     * @return string 
     */
    public function getNextmeetingat()
    {
        return $this->nextmeetingat;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
}
